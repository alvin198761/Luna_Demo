package com.tz.oa.sysmanage.service;

import java.util.List;
import java.util.Set;

import com.github.pagehelper.PageInfo;
import com.tz.oa.framework.dto.PageParam;
import com.tz.oa.sysmanage.Vo.UserVo;
import com.tz.oa.sysmanage.dto.UserDto;
import com.tz.oa.sysmanage.entity.User;
import com.tz.oa.sysmanage.entity.UserToRole;
/**
 * 用户业务接口
 * @author asus
 *
 */
public interface IUserService {
	
	/**
	 * 登录验证
	 * @param loginName
	 * @param password
	 * @return
	 */
	public User loginUser(String loginName,String password);
	
	/**
	 * @Title:         getUserById   
	 * @Description:   TODO(根据用户id获取用户明细信息)   
	 * @param:         @param userId
	 * @param:         @return      
	 * @return:        User   
	 * @author:        szq  
	 * @date:          2018年8月29日 上午11:46:18   
	 * @throws
	 */
	public User getUserById(Long userId);


	/**
	 * @Title:         updateUserPassword   
	 * @Description:   TODO(修改用户密码)   
	 * @param:         @param userId
	 * @param:         @param newPassword
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年8月29日 下午2:19:19   
	 * @throws
	 */
	public boolean updateUserPassword(Long userId, String newPassword);

	/**
	 * @Title:         getUserInfoById   
	 * @Description:   TODO(根据id获取用户明细 包含部门名称以及角色列表)   
	 * @param:         @param userId
	 * @param:         @return      
	 * @return:        UserDto   
	 * @author:        szq  
	 * @date:          2018年8月29日 下午3:31:00   
	 * @throws
	 */
	public UserDto getUserInfoById(long userId);

	/**
	 * @Title:         updateUser   
	 * @Description:   TODO(更新用户个人信息)   
	 * @param:         @param user
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年8月29日 下午4:16:20   
	 * @throws
	 */
	public boolean updateUser(User user);

	/**
	 * @Title:         getUserDtoList   
	 * @Description:   TODO(按条件分页查询用户列表)   
	 * @param:         @param user
	 * @param:         @param pageParam
	 * @param:         @return      
	 * @return:        PageInfo<UserDto>   
	 * @author:        szq  
	 * @date:          2018年9月5日 下午3:00:19   
	 * @throws
	 */
	public PageInfo<UserDto> getUserDtoList(User user, PageParam pageParam);

	/**
	 * @Title:         getUserRoleByUserId   
	 * @Description:   TODO(查询某个用户拥有的角色信息)   
	 * @param:         @param userId
	 * @param:         @return      
	 * @return:        List<UserToRole>   
	 * @author:        szq  
	 * @date:          2018年9月5日 下午3:36:09   
	 * @throws
	 */
	public List<UserToRole> getUserRoleByUserId(Long userId);
	
	/**
	 * 增加用户信息包含用户角色对应信息
	 * @param userVo
	 * @return
	 */
	public boolean addUser(UserVo userVo);

	/**
	 * 删除用户和用户对应关系表
	 * @param userId
	 * @return
	 */
	public boolean delUser(Long userId);

	/**
	 * 修改用户以及角色对应关系
	 * @param userVo
	 * @return
	 */
	public boolean updateUserVo(UserVo userVo);
	
	
	public PageInfo<UserDto> getUserDtoListTwo(List<Long> list, PageParam pageParam);
	

}
