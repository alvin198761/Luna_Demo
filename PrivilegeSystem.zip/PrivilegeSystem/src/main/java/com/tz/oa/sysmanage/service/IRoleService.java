package com.tz.oa.sysmanage.service;

import java.util.List;

import com.tz.oa.sysmanage.dto.RoleDto;
import com.tz.oa.sysmanage.entity.Role;
import com.tz.oa.sysmanage.entity.RoleToDept;
import com.tz.oa.sysmanage.entity.RoleToMenu;

public interface IRoleService {

	/**
	 * 查询所有的角色列表
	 * @return
	 */
	public List<Role> getAllRoleList();

	/**
	 * 增加角色信息
	 * @param roleDto
	 * @return
	 */
	public boolean addRole(RoleDto roleDto);

	/**
	 * 删除角色信息
	 * @param roleId
	 * @return
	 */
	public boolean delRole(Long roleId);
	
	
	/**
	 * 根据角色id查询角色菜单对应关系
	 * @param roleId
	 * @return
	 */
	public List<RoleToMenu> getMenuListByRoleId(Long roleId);

	/**
	 * 根据角色id查询角色部门对应关系
	 * @param roleId
	 * @return
	 */
	public List<RoleToDept> getDeptListByRoleId(Long roleId);


	/**
	 * 根据角色id获取角色信息
	 * @param roleId
	 * @return
	 */
	public Role getRoleById(Long roleId);

	/**
	 * 修改角色信息以及角色对应关系表
	 * @param roleDto
	 * @return
	 */
	public boolean updateRole(RoleDto roleDto);

	/**
	 * @Title:         updateRoleFlag   
	 * @Description:   TODO(修改角色信息禁用开启状态)   
	 * @param:         @param role
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年9月13日 下午2:49:48   
	 * @throws
	 */
	public boolean updateRoleFlag(Role role);

}
