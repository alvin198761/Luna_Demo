package com.tz.oa.sysmanage.service;

import java.util.List;

import com.tz.oa.sysmanage.entity.Menu;

public interface IMenuService {

	/**
	 * @Title:         getAllMenuList   
	 * @Description:   TODO(查询所有菜单列表)   
	 * @param:         @return      
	 * @return:        List<Menu>   
	 * @author:        szq  
	 * @date:          2018年8月31日 上午10:52:14   
	 * @throws
	 */
	public List<Menu> getAllMenuList();

	/**
	 * @Title:         getMenuById   
	 * @Description:   TODO(查询菜单明细)   
	 * @param:         @param menuId
	 * @param:         @return      
	 * @return:        Menu   
	 * @author:        szq  
	 * @date:          2018年8月31日 上午11:22:47   
	 * @throws
	 */
	public Menu getMenuById(Long menuId);

	/**
	 * @Title:         getChildCount   
	 * @Description:   TODO(获取某个节点的子节点数目,用于删除的特殊判断)   
	 * @param:         @param menuId
	 * @param:         @return      
	 * @return:        Integer   
	 * @author:        szq  
	 * @date:          2018年9月3日 上午10:27:30   
	 * @throws
	 */
	public Integer getChildCount(Long menuId);

	/**
	 * @Title:         delMenu   
	 * @Description:   TODO(删除菜单)   
	 * @param:         @param menuId
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年9月3日 上午10:34:19   
	 * @throws
	 */
	public boolean delMenu(Long menuId);

	/**
	 * @Title:         updateMenu   
	 * @Description:   TODO(修改菜单)   
	 * @param:         @param menu
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年9月3日 上午11:39:43   
	 * @throws
	 */
	public boolean updateMenu(Menu menu);

	/**
	 * @Title:         addMenu   
	 * @Description:   TODO(新增菜单)   
	 * @param:         @param menu
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年9月3日 上午11:39:49   
	 * @throws
	 */
	public boolean addMenu(Menu menu);

	/**
	 * @Title:         getMenuListByUserId   
	 * @Description:   TODO(查询用户权限控制类所拥有的所有菜单)   
	 * @param:         @param userId
	 * @param:         @return      
	 * @return:        List<Menu>   
	 * @author:        szq  
	 * @date:          2018年9月6日 上午10:31:29   
	 * @throws
	 */
	public List<Menu> getMenuListByUserId(Long userId);

}
