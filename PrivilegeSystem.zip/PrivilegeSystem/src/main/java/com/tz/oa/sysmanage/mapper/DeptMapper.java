package com.tz.oa.sysmanage.mapper;

import java.util.List;

import com.tz.oa.sysmanage.entity.Dept;

/**
 * 部门的增删改查mapper代理接口
 * @author asus
 *
 */
public interface DeptMapper {
	
	/**
	 * 查询所有部门列表
	 * @return
	 */
	public List<Dept> getAllDeptList();
	
	/**
	 * 获取某个节点的子节点数目,用于删除的特殊判断
	 * @param deptId
	 * @return
	 */
	public Integer getChildCount(Long deptId);
	
	/**
	 * 删除部门
	 * @param deptId
	 * @return
	 */
	public boolean delDept(Long deptId);
	
	/**
	 * 获取某个节点的子节点数目,用于删除的特殊判断
	 * @param deptId
	 * @return
	 */
	public Dept getDeptById(Long deptId);
	
	/**
	 * 修改部门
	 * @param dept
	 * @return
	 */
	public boolean updateDept(Dept dept);
	
	/**
	 * 新增部门
	 * @param dept
	 * @return
	 */

	public boolean addDept(Dept dept);

}