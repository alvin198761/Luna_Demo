package com.tz.oa.sysmanage.mapper;

import java.util.List;

import com.tz.oa.sysmanage.entity.Role;
import com.tz.oa.sysmanage.entity.RoleToDept;
import com.tz.oa.sysmanage.entity.RoleToMenu;

public interface RoleMapper {
	
	/**
	 * 查询所有的角色列表
	 * @return
	 */
	public List<Role> getAllRoleList();
	
	/**
	 * 增加角色信息
	 * @param roleDto
	 * @return
	 */
	public boolean addRole(Role role);
	
	/**
	 * 批量插入角色菜单对应信息
	 * @param roleMenuList
	 * @return
	 */
	public boolean addRoleToMenuBatch(List<RoleToMenu> roleMenuList);
	
	/**
	 * 批量插入角色部门对应信息
	 * @param roleDeptList
	 * @return
	 */
	public boolean addRoleToDeptBatch(List<RoleToDept> roleDeptList);
	
	
	/**
	 * 删除角色信息
	 * @param roleId
	 * @return
	 */
	public boolean delRole(Long roleId);

	/**
	 * 根据角色id删除角色菜单对应关系
	 * @param roleId
	 * @return
	 */
	public boolean delRoleMenuByRoleId(Long roleId);
	
	/**
	 * 根据角色id删除角色部门对应关系
	 * @param roleId
	 * @return
	 */
	public boolean delRoleDeptByRoleId(Long roleId);

	/**
	 * 根据角色id删除角色区域对应关系
	 * @param roleId
	 * @return
	 */
	//public boolean delRoleAreaByRoleId(Long roleId);

	/**
	 * 根据角色id查询角色菜单对应关系
	 * @param roleId
	 * @return
	 */
	public List<RoleToMenu> getMenuListByRoleId(Long roleId);

	/**
	 * 根据角色id查询角色部门对应关系
	 * @param roleId
	 * @return
	 */
	public List<RoleToDept> getDeptListByRoleId(Long roleId);


	/**
	 * 根据角色id获取角色信息
	 * @param roleId
	 * @return
	 */
	public Role getRoleById(Long roleId);

	/**
	 * 修改角色信息以及角色对应关系表
	 * @param roleDto
	 * @return
	 */
	public boolean updateRole(Role role);
	
	/**
	 * @Title:         updateRoleFlag   
	 * @Description:   TODO(修改角色信息禁用开启状态)   
	 * @param:         @param role
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年9月13日 下午2:49:48   
	 * @throws
	 */
	public boolean updateRoleFlag(Role role);
	
	/**
	 * 根据部门id删除所有部门角色对应关系记录
	 * @param deptId
	 * @return
	 */
	public boolean delRoleDeptByDeptId(Long deptId);
	
	/**
	 * 增加角色部门对应记录
	 * @param roleDept
	 * @return
	 */
	public boolean addRoleToDept(RoleToDept roleDept);
	
	/**
	 * 根据菜单id删除所有菜单角色对应关系记录
	 * @param menuId
	 * @return
	 */
	public boolean delRoleMenuByMenuId(Long menuId);
	
	/**
	 * 增加角色菜单对应记录
	 * @param roleMenu
	 * @return
	 */
	public boolean addRoleToMenu(RoleToMenu roleMenu);
}
