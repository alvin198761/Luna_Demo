package com.tz.oa.sysmanage.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.tz.oa.framework.dto.PageParam;
import com.tz.oa.sysmanage.dto.UserDto;
import com.tz.oa.sysmanage.entity.Dict;
import com.tz.oa.sysmanage.entity.User;

/**
 * @ClassName:     IDictService   
 * @Description:   TODO(字典业务接口)   
 * @author:        szq
 * @date:          2018年8月30日 下午6:29:01
 */
public interface IDictService {
	
	/**
	 * @Title:         getAllDictType   
	 * @Description:   TODO(获取所有的字典类型)   
	 * @param:         @return      
	 * @return:        List<String>   
	 * @author:        szq  
	 * @date:          2018年8月30日 下午6:30:37   
	 * @throws
	 */
	public List<String> getAllDictType();

	/**
	 * @Title:         getDictListPage   
	 * @Description:   TODO(分页查询字典列表)   
	 * @param:         @param dict
	 * @param:         @param pageParam
	 * @param:         @return      
	 * @return:        PageInfo<Dict>   
	 * @author:        szq  
	 * @date:          2018年8月30日 下午8:00:25   
	 * @throws
	 */
	public PageInfo<Dict> getDictListPage(Dict dict, PageParam pageParam);
	
	/**
	 * @Title:         getDictList   
	 * @Description:   TODO(根据条件查询字典列表)   
	 * @param:         @param dict
	 * @param:         @return      
	 * @return:        List<Dict>   
	 * @author:        szq  
	 * @date:          2018年8月30日 下午8:06:46   
	 * @throws
	 */
	public List<Dict> getDictList(Dict dict);

	/**
	 * @Title:         getDictById   
	 * @Description:   TODO(根据ID获取字典信息)   
	 * @param:         @param dictId
	 * @param:         @return      
	 * @return:        Dict   
	 * @author:        szq  
	 * @date:          2018年8月30日 下午8:41:08   
	 * @throws
	 */
	public Dict getDictById(Long dictId);
	
	/**
	 * @Title:         updateDict   
	 * @Description:   TODO(修改字典信息)   
	 * @param:         @param dict
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年8月30日 下午8:56:21   
	 * @throws
	 */
	public boolean updateDict(Dict dict);

	/**
	 * @Title:         addDict   
	 * @Description:   TODO(增加字典信息)   
	 * @param:         @param dict
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年8月30日 下午8:56:04   
	 * @throws
	 */
	public boolean addDict(Dict dict);

	/**
	 * @Title:         delDict   
	 * @Description:   TODO(根据dictId删除字典信息)   
	 * @param:         @param dictId
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年8月30日 下午9:20:52   
	 * @throws
	 */
	public boolean delDict(long dictId);
}
