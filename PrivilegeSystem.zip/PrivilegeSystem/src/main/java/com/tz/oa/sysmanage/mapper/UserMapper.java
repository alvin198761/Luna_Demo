package com.tz.oa.sysmanage.mapper;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.tz.oa.framework.dto.PageParam;
import com.tz.oa.sysmanage.dto.UserDto;
import com.tz.oa.sysmanage.entity.User;
import com.tz.oa.sysmanage.entity.UserToRole;

/**
 * 用户增删改查以及登陆验证的mapper代理接口
 * @author szq
 */
public interface UserMapper {
	/**
	 * @Title:         getUserList   
	 * @Description:   TODO(根据条件查询用户列表)   
	 * @param:         @param user
	 * @param:         @return      
	 * @return:        List<User>   
	 * @author:        szq  
	 * @date:          2018年8月29日 上午11:39:57   
	 * @throws
	 */
	public List<User> getUserList(User user);
	
	/**
	 * @Title:         getUserById   
	 * @Description:   TODO(根据用户id获取用户信息)   
	 * @param:         @param userId
	 * @param:         @return      
	 * @return:        User   
	 * @author:        szq  
	 * @date:          2018年8月29日 上午11:39:38   
	 * @throws
	 */
	public User getUserById(Long userId);

	//修改用户密码
	public boolean updateUserPassword(Long userId, String newPassword);

	/**
	 * @Title:         getUserInfoById   
	 * @Description:   TODO(根据id获取用户明细 包含部门名称以及角色列表)   
	 * @param:         @param userId
	 * @param:         @return      
	 * @return:        UserDto   
	 * @author:        szq  
	 * @date:          2018年8月29日 下午3:33:06   
	 * @throws
	 */
	public UserDto getUserInfoById(long userId);

	/**
	 * @Title:         updateUser   
	 * @Description:   TODO(更新用户个人信息)   
	 * @param:         @param user
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年8月29日 下午4:17:25   
	 * @throws
	 */
	public boolean updateUser(User user);
	
	/**
	 * @Title:         getUserDtoList   
	 * @Description:   TODO(按条件分页查询用户列表)   
	 * @param:         @param user
	 * @param:         @return      
	 * @return:        List<UserDto>   
	 * @author:        szq  
	 * @date:          2018年9月5日 下午3:00:19   
	 * @throws
	 */
	public List<UserDto> getUserDtoList(User user);
	
	/**
	 * @Title:         getUserRoleByUserId   
	 * @Description:   TODO(查询某个用户拥有的角色信息)   
	 * @param:         @param userId
	 * @param:         @return      
	 * @return:        List<UserToRole>   
	 * @author:        szq  
	 * @date:          2018年9月5日 下午3:36:09   
	 * @throws
	 */
	public List<UserToRole> getUserRoleByUserId(Long userId);
	
	public boolean delUserRoleByUserId(Long userId);

	public boolean delUser(Long userId);

	public boolean addUser(User user);

	public boolean addUserRoleBatch(List<UserToRole> userRoleList);
	
	public List<UserDto> getUserDtoListTwo(List<Long> list);
	
	
}
