package com.tz.oa.sysmanage.entity;

import java.util.Date;
 
/**
 * 
 * 类描述 字典对象bean：  
 * 类名称：com.tz.ssspm.sysmanage.bean.User       
 * 创建人：keven  
 * 创建时间：2016年11月5日 下午9:06:40
 * @version   V1.0
 */
public class Dict implements java.io.Serializable{
	
 	private static final long serialVersionUID = -5177134212031885106L;
	
 	private Long id;
 	private String value;
 	private String label;
 	private String type;
 	private String description;
 	private Integer sort;
 	private String parentId;	 
	private String	updateBy;
	private Date updateDate;
	private String remarks;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	 
	
}