package com.tz.oa.sysmanage.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tz.oa.framework.dto.PageParam;
import com.tz.oa.framework.util.UserUtils;
import com.tz.oa.sysmanage.Vo.UserVo;
import com.tz.oa.sysmanage.dto.UserDto;
import com.tz.oa.sysmanage.entity.User;
import com.tz.oa.sysmanage.entity.UserToRole;
import com.tz.oa.sysmanage.mapper.UserMapper;
import com.tz.oa.sysmanage.service.IUserService;
@Service
public class UserService implements IUserService{
	
	@Autowired
	private UserMapper userMapper;
	
	public User loginUser(String loginName, String password) {
		User user = new User();
		//1.把前台传过来的loginName赋值给user对象
		user.setLoginName(loginName);
		//2.根据loginName查出用户对象
		List<User> userList = userMapper.getUserList(user);
		//3.将查出来的用户对象的密码与界面输入过来的密码进行比对
		//判断一个顺序容器ArrayList里面是否有元素，如果有的话返回一个Boolean类型的值false，否则返回true
		if(userList.isEmpty()){//没有元素
			return null;
		}else{//有元素返回
			if(userList.get(0).getPassword().equals(password)){//和前台传回来的密码进行比对相等返回正确信息
				return userList.get(0);
			}else{
				return null;
			}
		}
	}


	//根据用户id获取用户明细信息
	public User getUserById(Long userId) {
		return userMapper.getUserById(userId);
	}



	//修改用户密码
	public boolean updateUserPassword(Long userId, String newPassword) {
		return userMapper.updateUserPassword(userId,newPassword);
	}


	public UserDto getUserInfoById(long userId) {
		return userMapper.getUserInfoById(userId);
	}


	public boolean updateUser(User user) {
		return userMapper.updateUser(user);
	}


	public PageInfo<UserDto> getUserDtoList(User user, PageParam pageParam) {
		PageHelper.startPage(pageParam.getPageNo(), pageParam.getPageSize());
		List<UserDto> userList = this.userMapper.getUserDtoList(user);
		PageInfo<UserDto> pageInfo = new PageInfo<UserDto>(userList);
		return pageInfo;
	}


	public List<UserToRole> getUserRoleByUserId(Long userId) {
		return userMapper.getUserRoleByUserId(userId);
	}


	@Transactional(isolation=Isolation.DEFAULT,propagation=Propagation.REQUIRED)
	public boolean addUser(UserVo userVo) {
		boolean flag = false;
		//增加的时候 ,注意填充当前操作的用户和实践
		User user = userVo.getUser();
		user.setUpdateBy(UserUtils.getCurrrentUserId().toString());
		user.setUpdateDate(new Date());
		//每次新增用户,其实是有一个默认密码
		String password = "123";
		user.setPassword(password);
		flag = this.userMapper.addUser(user);
		Long userId = user.getUserId();	
		//用户增加成功以后,需要讲用户和角色的对应关系放入到pm_sys_user_role
		//批量插入用户角色信息对应表
 		List<UserToRole> userRoleList = new ArrayList<UserToRole>();
  		UserToRole userRole;
  		Collection<Long> valuesRole = userVo.getRoleIds().values();
  		if(!valuesRole.isEmpty()){
  			for (Long roleId : valuesRole) {  		  
  	        	userRole = new UserToRole();
  	        	userRole.setUserId(userId);
  	        	userRole.setRoleId(roleId);
  	        	userRoleList.add(userRole);
  	         }
  	        flag = this.userMapper.addUserRoleBatch(userRoleList);
  		}
		return flag;
	}


	@Transactional(isolation=Isolation.DEFAULT,propagation=Propagation.REQUIRED)
	public boolean delUser(Long userId) {
		boolean flag = false;
		flag = this.userMapper.delUserRoleByUserId(userId);
		flag = this.userMapper.delUser(userId);
		return flag;
	}


	@Transactional(isolation=Isolation.DEFAULT,propagation=Propagation.REQUIRED)
	public boolean updateUserVo(UserVo userVo) {
		boolean flag = false;
		//修改的时候注意填充修改人和修改时间
		User user = userVo.getUser();
		user.setUpdateDate(new Date());
		user.setUpdateBy(UserUtils.getCurrrentUserId().toString());
		Long userId = user.getUserId();
		flag = userMapper.delUserRoleByUserId(userId);
		//批量插入用户角色信息对应表
		List<UserToRole> userRoleList = new ArrayList<UserToRole>();
		UserToRole userRole;
		for (Long roleId : userVo.getRoleIds().values()) {  		  
        	userRole = new UserToRole();
        	userRole.setUserId(userId);
        	userRole.setRoleId(roleId);
        	userRoleList.add(userRole);
         }
        flag = this.userMapper.addUserRoleBatch(userRoleList);
        
		flag =  userMapper.updateUser(user);
		return flag;
	}


	@Override
	public PageInfo<UserDto> getUserDtoListTwo(List<Long> list, PageParam pageParam) {
		PageHelper.startPage(pageParam.getPageNo(), pageParam.getPageSize());
		List<UserDto> userList = this.userMapper.getUserDtoListTwo(list);
		PageInfo<UserDto> pageInfo = new PageInfo<UserDto>(userList);
		return pageInfo;
	}

}
