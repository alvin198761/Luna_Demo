package com.tz.oa.sysmanage.service;

import java.util.List;

import com.tz.oa.sysmanage.entity.Dept;

public interface IDeptService {

	/**
	 * @Title:         getAllDeptList   
	 * @Description:   TODO(查询所有部门列表)   
	 * @param:         @return      
	 * @return:        List<Dept>   
	 * @author:        szq  
	 * @date:          2018年9月3日 下午2:45:56   
	 * @throws
	 */
	public List<Dept> getAllDeptList();

	/**
	 * @Title:         getDeptById   
	 * @Description:   TODO(查询部门明细)   
	 * @param:         @param deptId
	 * @param:         @return      
	 * @return:        Dept   
	 * @author:        szq  
	 * @date:          2018年9月3日 下午4:00:27   
	 * @throws
	 */
	public Dept getDeptById(Long deptId);

	/**
	 * @Title:         updateDept   
	 * @Description:   TODO(修改部门)   
	 * @param:         @param dept
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年9月4日 上午10:09:36   
	 * @throws
	 */
	public boolean updateDept(Dept dept);

	/**
	 * @Title:         addDept   
	 * @Description:   TODO(新增部门)   
	 * @param:         @param dept
	 * @param:         @return      
	 * @return:        boolean   
	 * @author:        szq  
	 * @date:          2018年9月4日 上午10:09:56   
	 * @throws
	 */
	public boolean addDept(Dept dept);
	
	/**
	 * 删除部门
	 * @param deptId
	 * @return
	 */
	public boolean delDept(Long deptId);
	
	/**
	 * 获取某个节点的子节点数目,用于删除的特殊判断
	 * @param deptId
	 * @return
	 */
	public Integer getChildCount(Long deptId);

}
