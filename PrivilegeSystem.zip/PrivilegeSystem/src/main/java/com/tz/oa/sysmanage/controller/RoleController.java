package com.tz.oa.sysmanage.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tz.oa.sysmanage.dto.RoleDto;
import com.tz.oa.sysmanage.entity.Dept;
import com.tz.oa.sysmanage.entity.Menu;
import com.tz.oa.sysmanage.entity.Role;
import com.tz.oa.sysmanage.entity.RoleToDept;
import com.tz.oa.sysmanage.entity.RoleToMenu;
import com.tz.oa.sysmanage.service.IDeptService;
import com.tz.oa.sysmanage.service.IMenuService;
import com.tz.oa.sysmanage.service.IRoleService;

/**
 * @ClassName:     RoleController   
 * @Description:   TODO(角色管理controller)   
 * @author:        szq
 * @date:          2018年9月4日 上午11:46:03
 */
@Controller
@RequestMapping("/sysmgr/role")
public class RoleController {
	
	private static Logger logger = Logger.getLogger(RoleController.class);
	
	@Autowired
	private IRoleService roleService;
	@Autowired 
	private IMenuService menuService;
	@Autowired
	private IDeptService deptService;
	
	//进入角色列表查询功能
	@RequestMapping("/gotoRoleList")
	public String gotoRoleList(Model model){
		//进入功能初始化所有的角色列表
		List<Role> roleList = new ArrayList<Role>();
		roleList = roleService.getAllRoleList();
		model.addAttribute("roleList", roleList);
		return "sysmanage/role/roleList";
	}
	
	@RequestMapping("/gotoRoleEdit")
	public String gotoRoleEdit(@ModelAttribute("editFlag") int editFlag,
			Long roleId,Model model){
		//不管是修改还是新增，我们都需要在编辑页面将部门树，菜单树，区域树显示出来
		List<Menu> menuList = menuService.getAllMenuList();
		List<Dept> deptList = deptService.getAllDeptList();
		model.addAttribute("menuList", menuList);
		model.addAttribute("deptList", deptList);
		//修改操作的时候，我们需要查询出该角色本身拥有的各项权限信息
		if(editFlag == 2){
			List<RoleToMenu> roleMenuList = roleService.getMenuListByRoleId(roleId);
			List<RoleToDept> roleDeptList = roleService.getDeptListByRoleId(roleId);
			model.addAttribute("roleMenuList", roleMenuList);
			model.addAttribute("roleDeptList", roleDeptList);
			Role role = roleService.getRoleById(roleId);
			model.addAttribute("role", role);
		}
		return "sysmanage/role/roleEdit";
	}
	
	@RequestMapping("/saveRole")
	public @ResponseBody Map<String, Object> saveRole(@RequestBody RoleDto roleDto){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			//判断新增还是修改,根据role对象是否有ID
			if(roleDto!=null&&roleDto.getRole()!=null&&roleDto.getRole().getId()!=null){
				//修改
				roleService.updateRole(roleDto);
				resultMap.put("result", "修改角色信息成功");
			}else {
				//新增
				roleService.addRole(roleDto);
				resultMap.put("result", "增加角色信息成功");
			}
		} catch (Exception e) {
			logger.error("操作角色信息失败", e);
			resultMap.put("result","增加角色信息失败");
		}
		return resultMap;
	}
	
	//删除角色
	@RequestMapping("/delRole")
	public @ResponseBody Map<String, Object> delRole(Long roleId){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			roleService.delRole(roleId);
			resultMap.put("result", "删除角色信息成功");
		} catch (Exception e) {
			logger.error("删除角色信息失败", e);
			resultMap.put("result", "删除角色信息失败");
		}
		return resultMap;
	}
	
	@RequestMapping("/updateRoleFlag")
	public @ResponseBody Map<String, Object> updateRoleFlag(String roleFlag,Long id){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			if(roleFlag!=null&&id!=null){
				Role role = new Role();
				role.setId(id);
				role.setRoleFlag(roleFlag);
				roleService.updateRoleFlag(role);
				resultMap.put("result", "修改角色开启/禁用信息成功");
			}else{
				resultMap.put("result","操作角色开启/禁用失败信息失败");
			}
			
		} catch (Exception e) {
			logger.error("操作角色开启/禁用失败信息失败", e);
			resultMap.put("result","操作角色开启/禁用失败信息失败");
		}
		return resultMap;
	}
}
